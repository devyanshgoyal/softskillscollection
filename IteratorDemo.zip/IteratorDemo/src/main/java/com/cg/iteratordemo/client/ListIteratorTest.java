package com.cg.iteratordemo.client;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.cg.iteratordemo.bean.Book;

public class ListIteratorTest {
	public static void main(String[] args) {

		List<Book> bookList = new ArrayList<>();

		bookList.add(new Book(1001, " Harry Potter and the Philosopher's Stone ", 600.00));
		bookList.add(new Book(1002, " Harry Potter and the Chamber of Secrets ", 750.00));
		bookList.add(new Book(1003, " Harry Potter and the Prisoner of Azkaban ", 920.00));
		bookList.add(new Book(1004, " Harry Potter and the Goblet of Fire ", 1150.00));
		bookList.add(new Book(1005, " Harry Potter and the Order of the Phoenix ", 1260.00));

//		iterateListUsingListIterator(bookList);
//		addElementsInListUsingListIterator(bookList);
//		deleteElementsInListUsingListIterator(bookList);
//		replaceElementsInListUsingListIterator(bookList);
	}

	private static void iterateListUsingListIterator(List<Book> bookList) {

		ListIterator<Book> listIterator = bookList.listIterator();
		System.out.println("Forward direction ->");
		while (listIterator.hasNext()) {
			Book book = listIterator.next();
			System.out.println(book);

		}
		System.out.println("Backward direction->");
		while (listIterator.hasPrevious()) {
			Book book = (Book) listIterator.previous();
			System.out.println(book);
		}
	}

	private static void addElementsInListUsingListIterator(List<Book> bookList) {
		ListIterator<Book> listIterator = bookList.listIterator();
		while (listIterator.hasNext()) {
			Book book = listIterator.next();
			if (!book.getBookName().equalsIgnoreCase(" Harry Potter and the Deathly Hallows ")) {
				listIterator.add(new Book(1006, " Harry Potter and the Deathly Hallows ", 1650.00));
				break;
			}
		}
		for (Book book : bookList) {
			System.out.println(book);
		}
	}

	private static void deleteElementsInListUsingListIterator(List<Book> bookList) {

		ListIterator<Book> listIterator = bookList.listIterator();
		while (listIterator.hasNext()) {
			Book book = listIterator.next();
			if (book.getBookName().equalsIgnoreCase(" Harry Potter and the Goblet of Fire ")) {
				listIterator.remove();
			}
		}
		for (Book book : bookList) {
			System.out.println(book);
		}

	}

	private static void replaceElementsInListUsingListIterator(List<Book> bookList) {

		ListIterator<Book> listIterator = bookList.listIterator();
		while (listIterator.hasNext()) {
			Book book = listIterator.next();
			if (book.getBookName().equalsIgnoreCase(" Harry Potter and the Deathly Hallows ")) {
				book.setBookName(" Harry Potter and the Deathly Hallows - Part 1 ");
				listIterator.set(book);
			}
		}
		for (Book book : bookList) {
			System.out.println(book);
		}

	}
}
