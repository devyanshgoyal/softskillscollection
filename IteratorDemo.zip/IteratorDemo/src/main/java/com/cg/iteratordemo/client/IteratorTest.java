package com.cg.iteratordemo.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.iteratordemo.bean.Book;

public class IteratorTest {

	public static void main(String[] args) {

		List<Book> bookList = new ArrayList<>();

		bookList.add(new Book(1001, " Harry Potter and the Philosopher's Stone ", 600.00));
		bookList.add(new Book(1002, " Harry Potter and the Chamber of Secrets ", 750.00));
		bookList.add(new Book(1003, " Harry Potter and the Prisoner of Azkaban ", 920.00));
		bookList.add(new Book(1004, " Harry Potter and the Goblet of Fire ", 1150.00));
		bookList.add(new Book(1005, " Harry Potter and the Order of the Phoenix ", 1260.00));

		Iterator<Book> iterator = bookList.iterator();
		while (iterator.hasNext()) {
			Book book = iterator.next();
			if (book.getBookPrice() <= 1000.00)
				iterator.remove();
		}

		Iterator<Book> iterator2 = bookList.iterator();
		while (iterator2.hasNext()) {
			Book book = iterator2.next();
			System.out.println(book);

			System.out.println("-------------------------");
			Iterator<Book> iterator3 = bookList.iterator();
			iterator3.forEachRemaining(System.out::println);
		}

	}
}
